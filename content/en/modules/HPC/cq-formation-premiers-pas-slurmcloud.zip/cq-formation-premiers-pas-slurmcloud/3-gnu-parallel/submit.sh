#!/bin/bash
#SBATCH --account= #TODO: add your account
#SBATCH --nodes=1
#SBATCH --ntasks-per-node=1
#####
# TODO: Add the option --cpus-per-task
#####
#SBATCH --mem-per-cpu=1000M
#SBATCH --time=5:00
#SBATCH --job-name=ex3

module load gcc boost

SRCDIR=../photos/

#####
# TODO: Add the parrallel command with the right files and arguments
#####
../filterImage.exe --srcdir $SRCDIR --files ... --filters grayscale
