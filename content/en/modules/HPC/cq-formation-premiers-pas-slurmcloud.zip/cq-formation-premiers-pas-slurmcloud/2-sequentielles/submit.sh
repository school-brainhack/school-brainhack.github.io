#!/bin/bash
#SBATCH --account= #TODO: add your account
#SBATCH --nodes=1
#SBATCH --ntasks-per-node=1
#SBATCH --cpus-per-task=1
#SBATCH --mem-per-cpu=1000M
#SBATCH --time=5:00
#SBATCH --job-name=ex2

# TODO: Load necessary modules
module load ....

# TODO: Update, if needed, the following path
SRCDIR=../photos/

####
# TODO: Add the right arguments to the command ../filterImage.exe
#      To turn a first image to grayscale.
# Use ../filterImage.exe --help to find the right arguments
####

../filterImage.exe --srcdir $SRCDIR ......
