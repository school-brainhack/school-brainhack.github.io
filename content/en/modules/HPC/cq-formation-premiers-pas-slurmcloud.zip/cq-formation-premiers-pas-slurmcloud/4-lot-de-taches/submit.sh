#!/bin/bash
#SBATCH --account= #TODO: add your account
#SBATCH --nodes=1
#SBATCH --ntasks-per-node=1
#SBATCH --cpus-per-task=2
#SBATCH --mem-per-cpu=1000M
#SBATCH --time=5:00
#####
# TODO: Add the right option for the array job
#####
#SBATCH --job-name=ex4

module load gcc boost

SRCDIR=../photos/

# List of available filters
FILTERS=(grayscale edges emboss negate solarize flip flop monochrome add_noise)

#####
# TODO: Use the FILTERS list to select the right filter according to the value
# of SLURM_ARRAY_TASK_ID
#####
parallel ../filterImage.exe --srcdir $SRCDIR --files {1} --filters FIXME ::: $(ls $SRCDIR)
